"""
3. Класс читателя
    - ???
"""

class Reader:
    def __init__(self, name : str, surname: str, age: int):
        """

        :param name: Имя читателя
        :param surname: Фамилия читателя
        :param age: Возраст читателя
        """
        self.name = name
        self.surname = surname
        self.age = age



