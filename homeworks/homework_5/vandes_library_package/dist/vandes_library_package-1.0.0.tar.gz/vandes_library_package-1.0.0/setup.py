from setuptools import setup

setup(
    name='vandes_library_package',
    version='1.0.0',
    description='vandes files from library',
    author='vandes',
    author_email='test@test.com',
    packages=['utils'],
    install_requires=['time']
)
